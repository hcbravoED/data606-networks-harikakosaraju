import numpy as np
from collections import deque

## TODO: Implement this function
##
## Implements the breadth-first algorithm of Girvan-Newman to compute
##   number (fractional) of shortest paths starting from a given vertex
##   that go through each edge of the graph
##
## Input:
##   - vertex (int): index of vertex paths start from
##   - mat (np.array): n-by-n adjacency matrix
##
## Output:
##   (np.array): n-by-n edge count matrix
##
## Note: assume input adjacency matrix is binary and symmetric
def edge_counts(vertex, mat):
    num_vertices = mat.shape[0]
    visited = [False] * num_vertices

    res = np.zeros((num_vertices, num_vertices))

    dists = [np.inf] * num_vertices
    paths = [0] * num_vertices

    dists[vertex] = 0
    paths[vertex] = 1

    q = deque()
    q.append(vertex)
    visited[vertex] = True

    while q:
        curr = q[0]
        q.popleft()

        # For all neighbors of current vertex do:
        adjs = [idx for idx, v in enumerate(mat[curr].tolist()) if v > 0]
        for x in adjs:

            # if the current vertex is not yet
            # visited, then push it to the queue.
            if not visited[x]:
                q.append(x)
                visited[x] = True

            # check if there is a better path.
            if dists[x] > dists[curr] + 1:
                dists[x] = dists[curr] + 1
                paths[x] = paths[curr]

            # additional shortest paths found
            elif dists[x] == dists[curr] + 1:
                paths[x] += paths[curr]

    dist = max(dists)
    values = [1] * num_vertices

    while dist > 0:
        vertices = [idx for idx, v in enumerate(dists) if v == dist]
        for cur_vertex in vertices:
            for upper_vertex in [idx for idx, v in enumerate(mat[cur_vertex].tolist()) if v > 0 and dists[idx] == dist-1]:
                values[upper_vertex] += values[cur_vertex] / paths[cur_vertex]
                res[cur_vertex][upper_vertex] = values[cur_vertex] / paths[cur_vertex]
                res[upper_vertex][cur_vertex] = values[cur_vertex] / paths[cur_vertex]
        dist -= 1

    return res

## Compute edge betweeness for a graph
## 
## Input: 
##   - mat (np.array): n-by-n adjacency matrix. 
##
## Output:
##   (np.array): n-by-n matrix of edge betweenness
##
## Notes: Input matrix is assumed binary and symmetric
def edge_betweenness(mat):
    res = np.zeros(mat.shape)
    num_vertices = mat.shape[0]
    for i in range(num_vertices):
        res += edge_counts(i, mat)
    res = res / 2.
    return res