import numpy as np

## TODO: Implement this function
##
## Input:
##  - dmat (np.array): symmetric array of distances
##  - K (int): Number of clusters
##
## Output:
##   (np.array): initialize by choosing random number of points as medioids
def random_init(dmat, K):
    num_vertices = dmat.shape[0]
    medioids = np.full((K), np.inf, dtype=np.int)
    idx = 0
    while idx < K:
        medioid = np.random.randint(num_vertices)
        if medioid in medioids:
            continue
        medioids[idx] = medioid
        idx += 1
    return medioids

## TODO: Implement this function
##
## Input:
##   - dmat (np.array): symmetric array of distances
##   - medioids (np.array): indices of current medioids
##
## Output:
##   - (np.array): assignment of each point to nearest medioid
def assign(dmat, mediods):
    num_vertices = dmat.shape[0]
    cur_labels = np.zeros((num_vertices))
    for i in range(num_vertices):
        # Distances from a data point to each of the medoids
        d_list = []
        for j in range(0, len(mediods)):
            d_list.append(dmat[mediods[j]][i])
        # Data points' label is the medoid which has minimal distance to it
        cur_labels[i] = d_list.index(min(d_list))

    return cur_labels

## TODO: Implement this function
##
## Input:
##   - dmat (np.array): symmetric array of distances
##   - assignment (np.array): cluster assignment for each point
##   - K (int): number of clusters
##
## Output:
##   (np.array): indices of selected medioids
def get_medioids(dmat, assignment, K):
    mediods = np.zeros((K))
    clusters = []
    for i in range(K):
        clusters.append(np.where(assignment == i)[0])

    for i in range(0, K):
        new_medoid = 0
        old_medoids_cost = np.inf
        for j in clusters[i]:
            # Cost of the current data points to be compared with the current optimal cost
            cur_medoids_cost = 0
            for dpoint_index in clusters[i]:
                cur_medoids_cost += dmat[j][dpoint_index]

            # If current cost is less than current optimal cost,
            # make the current data point new medoid of the cluster
            if cur_medoids_cost < old_medoids_cost:
                new_medoid = j
                old_medoids_cost = cur_medoids_cost

        # Now we have the optimal medoid of the current cluster
        mediods[i] = new_medoid

    return mediods

## TODO: Finish implementing this function
##
## Input:
##   - dmat (np.array): symmetric array of distances
##   - K (int): number of clusters
##   - niter (int): maximum number of iterations
##
## Output:
##   - (np.array): assignment of each point to cluster
def kmedioids(dmat, K, niter=10):
    num_vertices = dmat.shape[0]
    
    # we're checking for convergence by seeing if medioids
    # don't change so set some value to compare to
    old_medioids = np.full((K), np.inf, dtype=np.int)
    medioids = random_init(dmat, K)

    old_medioids_cost = np.inf

    # this is here to define the variable before the loop
    assignment = np.full((num_vertices), np.inf)
   
    it = 0
    while np.any(old_medioids != medioids) and it < niter:
        it += 1
        medioids = random_init(dmat, K)

        cur_assignment = np.full((num_vertices), np.inf)

        # Dissimilarity cost of the current cluster
        cur_medoids_cost = 0

        # finish implementing this section
        for k in range(num_vertices):
            # Distances from a data point to each of the medoids
            d_list = []
            for j in range(0, K):
                d_list.append(dmat[medioids[j]][k])

            cur_assignment[k] = d_list.index(min(d_list))
            cur_medoids_cost += min(d_list)

        if cur_medoids_cost < old_medioids_cost:
            # Data points' label is the medoid which has minimal distance to it
            old_medioids_cost = cur_medoids_cost
            assignment = cur_assignment

        medioids = random_init(dmat, K)

    return assignment
        