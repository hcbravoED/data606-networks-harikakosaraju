import numpy as np
from collections import deque

## TODO: Implement this function
##
## input:
##   mat (np.array): adjacency matrix for graph
## 
## returns:
##   (np.array): distance matrix
##
## Note: You can assume input matrix is binary, square and symmetric 
##       Your output should be square and symmetric
def bfs_distance(mat):
    num_vertices = mat.shape[0]    
    res = np.full((num_vertices, num_vertices), np.inf)

    # Finish this loop
    for i in range(num_vertices):
        d = deque()
        visited = [False for _ in range(num_vertices)]
        d.append((i, 0))
        while len(d) != 0:
            tup = d.popleft()
            if visited[tup[0]]:
                continue
            visited[tup[0]] = True
            res[i][tup[0]] = tup[1]

            for j in range(len(mat[tup[0]])):
                if mat[tup[0]][j] == 1:
                    if not visited[j]:
                        d.append((j, tup[1] + 1))
    return res



## TODO: Implement this function
##
## input:
##   mat (np.array): adjacency matrix for graph
## 
## returns:
##   (list of np.array): list of components
##
## Note: You can assume input matrix is binary, square and symmetric 
##       Your output should be square and symmetric
def get_components(mat):
    dist_mat = bfs_distance(mat)
    num_vertices = mat.shape[0]
    available = [False for _ in range(num_vertices)]

    components = []

    u = 0
    # finish this loop
    while not all(available):
        if available[u]:
            u += 1
            continue
        available[u] = True
        component = [u]
        for v in range(u+1, len(available)):
            if dist_mat[u][v] < np.inf:
                component.append(v)
                available[v] = True

        u += 1
        components.append(component)
    
    return components
